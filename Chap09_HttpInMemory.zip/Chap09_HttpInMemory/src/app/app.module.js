"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var personData_1 = require("./resources/data/personData");
var A08_crud_component_1 = require("./components/A08.crud.component");
var core_1 = require("@angular/core");
var platform_browser_1 = require("@angular/platform-browser");
var angular_in_memory_web_api_1 = require("angular-in-memory-web-api");
var forms_1 = require("@angular/forms");
var http_1 = require("@angular/http");
var AppModule = (function () {
    function AppModule() {
    }
    return AppModule;
}());
AppModule = __decorate([
    core_1.NgModule({
        imports: [platform_browser_1.BrowserModule, forms_1.FormsModule, http_1.HttpModule,
            angular_in_memory_web_api_1.InMemoryWebApiModule.forRoot(personData_1.PersonData) // 작성한 테이터를 root에 올린다
        ],
        declarations: [A08_crud_component_1.A08Component],
        bootstrap: [A08_crud_component_1.A08Component]
    })
], AppModule);
exports.AppModule = AppModule;
//# sourceMappingURL=app.module.js.map